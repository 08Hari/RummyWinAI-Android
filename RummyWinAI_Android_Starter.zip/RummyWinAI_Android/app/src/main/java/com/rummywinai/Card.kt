package com.rummywinai

data class Card(val rank: Int, val suit: Char) {
    override fun toString(): String = "${rankLabel(rank)}$suit"

    companion object {
        fun parse(token: String): Card? {
            val t = token.trim().uppercase()
            if (t.length !in 2..3) return null
            val suit = t.last()
            if (suit !in "HDSC") return null
            val r = t.dropLast(1)
            val rank = when (r) {
                "A" -> 1
                "J" -> 11
                "Q" -> 12
                "K" -> 13
                else -> r.toIntOrNull()
            } ?: return null
            if (rank !in 1..13) return null
            return Card(rank, suit)
        }

        fun rankLabel(rank: Int) = when (rank) {
            1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> rank.toString()
        }
    }
}
