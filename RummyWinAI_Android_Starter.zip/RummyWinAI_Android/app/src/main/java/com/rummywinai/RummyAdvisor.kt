package com.rummywinai

data class Advice(val score: Int, val discard: Card?, val note: String)

object RummyAdvisor {
    // Heuristic hand-strength indicator only; not a calibrated win probability.
    fun analyse(cards: List<Card>): Advice {
        if (cards.size != 13) return Advice(0, null, "Enter exactly 13 cards.")
        if (cards.distinct().size != cards.size) return Advice(0, null, "Duplicate card detected.")

        val protected = mutableSetOf<Card>()
        val bySuit = cards.groupBy { it.suit }
        bySuit.forEach { (_, suited) ->
            val sorted = suited.sortedBy { it.rank }
            for (i in sorted.indices) {
                for (j in i + 1 until sorted.size) {
                    val gap = sorted[j].rank - sorted[i].rank
                    if (gap <= 2) {
                        protected.add(sorted[i])
                        protected.add(sorted[j])
                    }
                }
            }
        }
        val byRank = cards.groupBy { it.rank }
        byRank.values.filter { it.size >= 2 }.flatten().forEach { protected.add(it) }

        val candidates = cards.filter { it !in protected }.ifEmpty { cards }
        val discard = candidates.minByOrNull { c ->
            val sameSuitNeighbours = cards.count {
                it != c && it.suit == c.suit && kotlin.math.abs(it.rank - c.rank) <= 2
            }
            val sameRank = cards.count { it != c && it.rank == c.rank }
            sameSuitNeighbours * 4 + sameRank * 5 - deadwoodValue(c)
        }

        val kept = cards.size - (discard?.let { 1 } ?: 0)
        val score = (protected.size * 7).coerceIn(0, 95)
        val note = when {
            protected.size >= 9 -> "Several connected groups found. Verify sequence requirements."
            protected.size >= 5 -> "Some useful connections found. Prioritise a pure sequence."
            else -> "Few strong connections found. Reduce isolated high-value cards."
        }
        return Advice(score, discard, note)
    }

    private fun deadwoodValue(c: Card) = when {
        c.rank == 1 -> 10
        c.rank >= 10 -> 10
        else -> c.rank
    }
}
