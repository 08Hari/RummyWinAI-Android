package com.rummywinai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingPanelService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: TextView? = null

    override fun onCreate() {
        super.onCreate()
        startAsForegroundService()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        panel = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xE6222B35.toInt())
            setPadding(18, 14, 18, 14)
            setOnClickListener { refreshText() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 180
        }
        windowManager?.addView(panel, params)
        refreshText()
    }

    private fun startAsForegroundService() {
        val channelId = "rummy_winai_overlay"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Rummy WinAI floating panel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("Rummy WinAI is active")
                .setContentText("Floating strategy panel is running.")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Rummy WinAI is active")
                .setContentText("Floating strategy panel is running.")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .build()
        }
        startForeground(41, notification)
    }

    private fun refreshText() {
        val advice = getSharedPreferences("rummywinai", MODE_PRIVATE)
            .getString("advice", "No analysis yet. Open Rummy WinAI and analyse a hand.")
        panel?.text = "RUMMY WINAI\\n$advice\\nTap to refresh"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refreshText()
        return START_STICKY
    }

    override fun onDestroy() {
        panel?.let { windowManager?.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
