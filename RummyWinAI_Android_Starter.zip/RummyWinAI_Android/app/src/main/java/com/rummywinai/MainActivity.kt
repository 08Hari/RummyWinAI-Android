package com.rummywinai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequestCode = 4102
    private lateinit var cardsInput: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Rummy WinAI"
            textSize = 28f
        }
        val intro = TextView(this).apply {
            text = "MVP • 13-card Points Rummy strategy assistant\nEnter visible cards as rank+suit, separated by commas. Example: AH,2H,3H,7D,7S,..."
            textSize = 14f
            setPadding(0, 12, 0, 16)
        }
        cardsInput = EditText(this).apply {
            hint = "AH,2H,3H,7D,7S, ..."
            minLines = 3
            gravity = Gravity.TOP
        }
        val analyse = Button(this).apply {
            text = "Analyse hand"
            setOnClickListener { analyseHand() }
        }
        val float = Button(this).apply {
            text = "Enable floating panel"
            setOnClickListener { enableFloatingPanel() }
        }
        val capture = Button(this).apply {
            text = "Start permitted screen capture"
            setOnClickListener { requestScreenCapture() }
        }
        result = TextView(this).apply {
            text = "Analysis will appear here."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        layout.addView(title)
        layout.addView(intro)
        layout.addView(cardsInput)
        layout.addView(analyse)
        layout.addView(float)
        layout.addView(result)
        setContentView(layout)
    }

    private fun analyseHand() {
        val tokens = cardsInput.text.toString().split(',', ' ', '\n').filter { it.isNotBlank() }
        val cards = tokens.mapNotNull { Card.parse(it) }
        if (cards.size != tokens.size) {
            result.text = "Some cards could not be read. Use formats like AH, 10S, QD."
            return
        }
        val advice = RummyAdvisor.analyse(cards)
        result.text = "Hand-strength indicator: ${advice.score}/100\nSuggested discard: ${advice.discard ?: "—"}\n${advice.note}\n\nThis is a heuristic, not a win probability."
        getSharedPreferences("rummywinai", MODE_PRIVATE).edit()
            .putString("advice", result.text.toString()).apply()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this, "Screen capture started with your permission.", Toast.LENGTH_LONG).show()
        }
    }

    private fun enableFloatingPanel() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Allow 'Display over other apps', then tap this again.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Floating panel started.", Toast.LENGTH_SHORT).show()
    }
}
