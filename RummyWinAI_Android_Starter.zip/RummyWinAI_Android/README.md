# Rummy WinAI Android (prototype)

Android 15-targeted prototype for a user-visible floating Points Rummy strategy assistant.

## Current prototype scope
- Android app shell and floating overlay permission flow.
- User-consented MediaProjection capture service foundation.
- Manual 13-card input and a simple heuristic discard suggestion.

## Not implemented yet
- Automatic card recognition/OCR or playing-card detection.
- Full Points Rummy rules validation and robust discard search.
- Live recommendations from captured frames.

This prototype does not access hidden cards, predict future draws, automate gameplay, or guarantee wins. Screen capture may be blocked by protected/FLAG_SECURE screens; do not bypass those protections.

## Build
Use Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17, Android SDK 35. In this project directory run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
